// src/utils/authRefresh.js

export const refreshToken = async () => {
  try {
    console.log("========== BẮT ĐẦU LÀM MỚI TOKEN ==========");

    const url = "http://localhost:8080/api/auth/refresh-token";
    console.log("Gọi API làm mới token tại:", url);

    const res = await fetch(url, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!res.ok) {
      const error = await res.json();
      console.error("Lỗi khi làm mới token - Chi tiết lỗi:", error);
      throw new Error(error.message || "Không thể làm mới token");
    }

    const data = await res.json();
    console.log("Dữ liệu nhận được sau khi làm mới token:", data);

    const newAccessToken = data?.data?.accessToken || data?.accessToken;
    if (!newAccessToken) {
      throw new Error("Không nhận được accessToken mới");
    }

    localStorage.setItem("accessToken", newAccessToken);
    console.log("Đã lưu token mới vào localStorage:", newAccessToken);

    return { accessToken: newAccessToken };
  } catch (err) {
    console.error("Lỗi khi làm mới token:", err);
    throw err;
  }
};
