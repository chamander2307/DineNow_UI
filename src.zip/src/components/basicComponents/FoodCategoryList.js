import React, { useState, useEffect } from "react";
import "../../assets/styles/home/FilterBar.css";
import { fetchMainCategories } from "../../services/menuItemService";
import buffet from "../../assets/img/buffet.png";
import lau from "../../assets/img/lau.png";
import nuong from "../../assets/img/nuong.png";
import haisan from "../../assets/img/haisan.png";
import quannhau from "../../assets/img/quannhau.png";
import nhat from "../../assets/img/nhat.png";
import viet from "../../assets/img/viet.png";
import han from "../../assets/img/han.png";
import chay from "../../assets/img/chay.png";

const iconMap = {
  Buffet: buffet,
  Lẩu: lau,
  Nướng: nuong,
  "Hải sản": haisan,
  "Quán nhậu": quannhau,
  "Món Nhật": nhat,
  "Món Việt": viet,
  "Món Hàn": han,
  "Món chay": chay,
};

const FoodCategoryList = () => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const data = await fetchMainCategories();
        setCategories(data || []);
      } catch (error) {
        console.error("Lỗi khi tải danh mục món ăn:", error);
      }
    };
    loadCategories();
  }, []);

  return (
    <div className="food-category-list">
      {categories.map((category) => (
        <div className="food-category-item" key={category.id}>
          <img
            className="circle-img"
            src={iconMap[category.name] || "/fallback.jpg"}
            alt={category.name}
          />
          <span>{category.name}</span>
        </div>
      ))}
    </div>
  );
};

export default FoodCategoryList;