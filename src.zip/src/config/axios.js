// src/config/axios.js

import axios from "axios";
import { refreshToken } from "../utils/authRefresh";

const instance = axios.create({
  baseURL: "http://localhost:8080",
  withCredentials: true,
});

console.log("========== KHỞI TẠO AXIOS ==========");

// Hàm kiểm tra token đã hết hạn chưa
const isTokenExpired = (token) => {
  if (!token) return true;
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    const currentTime = Math.floor(Date.now() / 1000);
    return payload.exp < currentTime;
  } catch (error) {
    console.error("Lỗi khi phân tích token:", error);
    return true;
  }
};

// Trước khi gửi request, kiểm tra token
instance.interceptors.request.use(async (config) => {
  try {
    let token = localStorage.getItem("accessToken");

    // Nếu token không tồn tại hoặc hết hạn, thực hiện làm mới
    if (!token || isTokenExpired(token)) {
      console.warn("Token đã hết hạn hoặc không tồn tại, thử làm mới token...");
      try {
        const data = await refreshToken();
        token = data?.accessToken;
        if (token) {
          console.log("Token mới sau khi làm mới:", token);
          localStorage.setItem("accessToken", token);
        } else {
          throw new Error("Không nhận được token mới");
        }
      } catch (refreshError) {
        console.error("Lỗi khi làm mới token trong request:", refreshError);
        localStorage.removeItem("accessToken");
        window.location.href = "/login";
        throw refreshError;
      }
    }

    // Thêm token vào header
    if (token) {
      if (token.startsWith('"') && token.endsWith('"')) {
        token = token.slice(1, -1);
      }
      config.headers["Authorization"] = `Bearer ${token}`;
      console.log("Gửi token trong request:", config.headers["Authorization"]);
    } else {
      console.warn("Không tìm thấy token trong localStorage!");
    }

    return config;
  } catch (error) {
    console.error("Lỗi trong request interceptor:", error);
    return config;
  }
});

// Interceptor cho response
instance.interceptors.response.use(
  (response) => {
    console.log("========== NHẬN PHẢN HỒI ==========");
    return response;
  },
  async (error) => {
    console.error("========== LỖI RESPONSE ==========");
    console.error("Chi tiết lỗi:", error.response?.status, error.response?.data);

    const originalRequest = error.config;
    if ((error.response?.status === 401 || error.response?.status === 403) && !originalRequest._retry) {
      originalRequest._retry = true;
      console.log("Token hết hạn hoặc không hợp lệ, thử làm mới token...");

      try {
        const data = await refreshToken();
        const newAccessToken = data?.accessToken;

        if (newAccessToken) {
          console.log("Token mới sau khi làm mới:", newAccessToken);
          localStorage.setItem("accessToken", newAccessToken);
          originalRequest.headers["Authorization"] = `Bearer ${newAccessToken}`;
          return instance(originalRequest);
        } else {
          console.error("Không có token mới, chuyển hướng về trang đăng nhập!");
          throw new Error("Không thể làm mới token");
        }
      } catch (e) {
        console.error("Lỗi khi làm mới token từ interceptor:", e);
        localStorage.removeItem("accessToken");
        window.location.href = "/login";
        return Promise.reject(e);
      }
    }

    return Promise.reject(error);
  }
);

export default instance;
